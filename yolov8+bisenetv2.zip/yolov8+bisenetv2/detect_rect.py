import cv2
import numpy as np



def detect_rect(contours):
    squares = []
    for c in contours:
        rect = cv2.minAreaRect(c)


    return rect[0],rect[1],rect[2]

