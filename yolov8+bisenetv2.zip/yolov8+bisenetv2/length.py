import cv2
import numpy as np
from skimage.morphology import skeletonize

img_path = r'C:\Users\lenovo\Desktop\ys\CrackForest-dataset-master\png\001.png'

def get_skeleton(blobs):
    """
    骨骼提取
    """
    img = cv2.imread(blobs, cv2.IMREAD_COLOR)
    skeleton = skeletonize(img)  # ndarray, 为TRUE的元素代表骨骼线的位置
    skeleton_pts = np.argwhere(skeleton)
    return skeleton, skeleton_pts

length = 0

# 求skeleton
s_skeleton, s_skeleton_pts = get_skeleton(img_path)
# 利用骨骼线得到轮廓
s_bpixel = np.zeros_like(s_skeleton, dtype=np.uint8)
s_bpixel[s_skeleton] = 255
s_contours, _ = cv2.findContours(s_bpixel, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
# 计算长度
for s_contour in s_contours:
    length += cv2.arcLength(s_contour, True) / 2

print("长度：", length)