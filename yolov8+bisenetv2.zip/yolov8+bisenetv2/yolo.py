import colorsys
import os
import time

import numpy as np
import torch
import torch.nn as nn
from PIL import ImageDraw, ImageFont

from nets.yolo import YoloBody
from utils.utils import (cvtColor, get_classes, preprocess_input,
                         resize_image, show_config, resizese_image)
from utils.utils_bbox import DecodeBox
from nets.bisenetv2 import BiSeNetV2 as unet
from detect_rect import detect_rect
from MaxCircle import max_circle

'''
训练自己的数据集必看注释！
'''
class YOLO(object):
    compute = open('compute.txt', 'w+', encoding='utf-8')
    compute.close()
    tpynum = open('tpynum.txt', 'w+', encoding='utf-8')
    for i in range(4):
        tpynum.write("0" + "\n")
    tpynum.close()
    _defaults = {
        #--------------------------------------------------------------------------#
        #   使用自己训练好的模型进行预测一定要修改model_path和classes_path！
        #   model_path指向logs文件夹下的权值文件，classes_path指向model_data下的txt
        #
        #   训练好后logs文件夹下存在多个权值文件，选择验证集损失较低的即可。
        #   验证集损失较低不代表mAP较高，仅代表该权值在验证集上泛化性能较好。
        #   如果出现shape不匹配，同时要注意训练时的model_path和classes_path参数的修改
        #--------------------------------------------------------------------------#
        "model_path"        : 'model_data/best_epoch_weights.pth',
        "modelse_path"      : 'model_data/best_epoch_weightsseg.pth',
        "classes_path"      : 'model_data/voc_classes.txt',
        #---------------------------------------------------------------------#
        #   输入图片的大小，必须为32的倍数。
        #---------------------------------------------------------------------#
        "input_shape"       : [640, 640],
        #------------------------------------------------------#
        #   所使用到的yolov8的版本：
        #   n : 对应yolov8_n
        #   s : 对应yolov8_s
        #   m : 对应yolov8_m
        #   l : 对应yolov8_l
        #   x : 对应yolov8_x
        #------------------------------------------------------#

        "phi"               : 'n',
        #---------------------------------------------------------------------#
        #   只有得分大于置信度的预测框会被保留下来
        #---------------------------------------------------------------------#
        "confidence"        : 0.5,
        #---------------------------------------------------------------------#
        #   非极大抑制所用到的nms_iou大小
        #---------------------------------------------------------------------#
        "nms_iou"           : 0.3,
        #---------------------------------------------------------------------#
        #   该变量用于控制是否使用letterbox_image对输入图像进行不失真的resize，
        #   在多次测试后，发现关闭letterbox_image直接resize的效果更好
        #---------------------------------------------------------------------#
        "letterbox_image"   : True,
        #-------------------------------#
        #   是否使用Cuda
        #   没有GPU可以设置成False
        #-------------------------------#
        "cuda"              : False,

        # -------------------------------------------------#
        #   mix_type参数用于控制检测结果的可视化方式
        #
        #   mix_type = 0的时候代表原图与生成的图进行混合
        #   mix_type = 1的时候代表仅保留生成的图
        #   mix_type = 2的时候代表仅扣去背景，仅保留原图中的目标
        # -------------------------------------------------#
        "mix_type": 0,
        # --------------------------------#
    }

    @classmethod
    def get_defaults(cls, n):
        if n in cls._defaults:
            return cls._defaults[n]
        else:
            return "Unrecognized attribute name '" + n + "'"

    #---------------------------------------------------#
    #   初始化YOLO
    #---------------------------------------------------#
    def __init__(self, **kwargs):
        self.__dict__.update(self._defaults)
        for name, value in kwargs.items():
            setattr(self, name, value)
            self._defaults[name] = value 
            
        #---------------------------------------------------#
        #   获得种类和先验框的数量
        #---------------------------------------------------#
        self.class_names, self.num_classes  = get_classes(self.classes_path)
        self.bbox_util                      = DecodeBox(self.num_classes, (self.input_shape[0], self.input_shape[1]))
        #---------------------------------------------------#
        #   画框设置不同的颜色
        #---------------------------------------------------#
        hsv_tuples = [(x / self.num_classes, 1., 1.) for x in range(self.num_classes)]
        self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
        self.colors = list(map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), self.colors))
        self.generate()
        self.generatese()

        show_config(**self._defaults)

    #---------------------------------------------------#
    #   生成模型
    #---------------------------------------------------#
    def generate(self, onnx=False):
        #---------------------------------------------------#
        #   建立yolo模型，载入yolo模型的权重
        #---------------------------------------------------#
        self.net    = YoloBody(self.input_shape, self.num_classes, self.phi)

        device      = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net.load_state_dict(torch.load(self.model_path, map_location=device))
        self.net    = self.net.fuse().eval()
        print('{} model, and classes loaded.'.format(self.model_path))
        if not onnx:
            if self.cuda:
                self.net = nn.DataParallel(self.net)
                self.net = self.net.cuda()

    # ---------------------------------------------------#
    #   生成分割模型
    # ---------------------------------------------------#
    def generatese(self, onnx=False):
        # ---------------------------------------------------#
        #   建立bise模型，载入bise模型的权重
        # ---------------------------------------------------#
        self.netse = unet(n_classes=2, aux_mode='train')

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.netse.load_state_dict(torch.load(self.modelse_path, map_location=device))
        self.netse = self.netse.eval()
        print('{} model, and classes loaded.'.format(self.modelse_path))
        if not onnx:
            if self.cuda:
                self.net = nn.DataParallel(self.net)
                self.net = self.net.cuda()

        #---------------------------------------------------#
        #   分割模型设置不同的颜色
        #---------------------------------------------------#
        #self.colorse = [ (255, 255, 255), (255, 0, 0)]  #设置为0时  保证目标可以嵌入原图

        #self.colorse = [(0, 0, 0), (255, 255, 255)]    #设置为1时  实现背景为黑目标为白
    #---------------------------------------------------#
    #   检测图片
    #---------------------------------------------------#
    def detect_image(self, image, crop = False, count = False, name = 0):
        #---------------------------------------------------#
        #   计算输入图片的高和宽
        #---------------------------------------------------#
        image_shape = np.array(np.shape(image)[0:2])
        #---------------------------------------------------------#
        #   在这里将图像转换成RGB图像，防止灰度图在预测时报错。
        #   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
        #---------------------------------------------------------#
        image       = cvtColor(image)
        #---------------------------------------------------------#
        #   给图像增加灰条，实现不失真的resize
        #   也可以直接resize进行识别
        #---------------------------------------------------------#
        image_data  = resize_image(image, (self.input_shape[1], self.input_shape[0]), self.letterbox_image)
        #---------------------------------------------------------#
        #   添加上batch_size维度
        #   h, w, 3 => 3, h, w => 1, 3, h, w
        #---------------------------------------------------------#
        image_data  = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

        with torch.no_grad():
            images = torch.from_numpy(image_data)
            if self.cuda:
                images = images.cuda()
            #---------------------------------------------------------#
            #   将图像输入网络当中进行预测！
            #---------------------------------------------------------#
            outputs = self.net(images)
            outputs = self.bbox_util.decode_box(outputs)
            #---------------------------------------------------------#
            #   将预测框进行堆叠，然后进行非极大抑制
            #---------------------------------------------------------#
            results = self.bbox_util.non_max_suppression(outputs, self.num_classes, self.input_shape, 
                        image_shape, self.letterbox_image, conf_thres = self.confidence, nms_thres = self.nms_iou)
                                                    
            if results[0] is None: 
                return image#, image

            top_label   = np.array(results[0][:, 5], dtype = 'int32')
            top_conf    = results[0][:, 4]
            top_boxes   = results[0][:, :4]

            for i, c in list(enumerate(top_boxes)):
                top, left, bottom, right = top_boxes[i]
                top     = max(0, np.floor(top).astype('int32'))
                left    = max(0, np.floor(left).astype('int32'))
                bottom  = min(image.size[1], np.floor(bottom).astype('int32'))
                right   = min(image.size[0], np.floor(right).astype('int32'))
                crop_image = image.crop([left, top, right, bottom])

                from PIL import Image
                import cv2
                import copy
                import torch.nn.functional as F

                crop_image = cvtColor(crop_image)
                # ---------------------------------------------------#
                #   对输入图像进行一个备份，后面用于绘图
                # ---------------------------------------------------#
                old_img = copy.deepcopy(crop_image)
                orininal_h = np.array(crop_image).shape[0]
                orininal_w = np.array(crop_image).shape[1]
                # ---------------------------------------------------------#
                #   给图像增加灰条，实现不失真的resize
                #   也可以直接resize进行识别
                # ---------------------------------------------------------#
                image_data, nw, nh = resizese_image(crop_image, (self.input_shape[1], self.input_shape[0]))
                # image_data.show()
                # ---------------------------------------------------------#
                #   添加上batch_size维度
                # ---------------------------------------------------------#
                image_data = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, np.float32)), (2, 0, 1)),
                                            0)

                with torch.no_grad():
                    images = torch.from_numpy(image_data)
                    if self.cuda:
                        images = images.cuda()

                    # ---------------------------------------------------#
                    #   图片传入网络进行预测
                    # ---------------------------------------------------#
                    pr = self.netse(images)[0][0]
                    # ---------------------------------------------------#
                    #   取出每一个像素点的种类
                    # ---------------------------------------------------#
                    pr = F.softmax(pr.permute(1, 2, 0), dim=-1).cpu().numpy()
                    # --------------------------------------#
                    #   将灰条部分截取掉
                    # --------------------------------------#
                    pr = pr[int((self.input_shape[0] - nh) // 2): int((self.input_shape[0] - nh) // 2 + nh), \
                         int((self.input_shape[1] - nw) // 2): int((self.input_shape[1] - nw) // 2 + nw)]
                    # ---------------------------------------------------#
                    #   进行图片的resize
                    # ---------------------------------------------------#
                    pr = cv2.resize(pr, (orininal_w, orininal_h), interpolation=cv2.INTER_LINEAR)
                    # ---------------------------------------------------#
                    #   取出每一个像素点的种类
                    # ---------------------------------------------------#
                    pr = pr.argmax(axis=-1)
                    if self.mix_type == 0:

                        self.colorse = [(0, 0, 0), (255, 255, 255)]
                        seg_img = np.reshape(np.array(self.colorse, np.uint8)[np.reshape(pr, [-1])],
                                              [orininal_h, orininal_w, -1])
                        length, max_w = max_circle(seg_img)

                        self.colorse = [(255, 255, 255), (255, 0, 0)]  # 设置为0时  保证目标可以嵌入原图
                        # seg_img = np.zeros((np.shape(pr)[0], np.shape(pr)[1], 3))
                        # for c in range(self.num_classes):
                        #     seg_img[:, :, 0] += ((pr[:, :] == c ) * self.colors[c][0]).astype('uint8')
                        #     seg_img[:, :, 1] += ((pr[:, :] == c ) * self.colors[c][1]).astype('uint8')
                        #     seg_img[:, :, 2] += ((pr[:, :] == c ) * self.colors[c][2]).astype('uint8')
                        seg_img = np.reshape(np.array(self.colorse, np.uint8)[np.reshape(pr, [-1])],
                                             [orininal_h, orininal_w, -1])
                        #Crevice = max_circle(seg_img)
                        # ------------------------------------------------#
                        #   将新图片转换成Image的形式
                        # ------------------------------------------------#
                        r_image = Image.fromarray(np.uint8(seg_img))
                        # ------------------------------------------------#
                        #   将新图与原图及进行混合
                        # ------------------------------------------------#
                        r_image = Image.blend(old_img, r_image, 0.1)

                    elif self.mix_type == 1:

                        self.colorse = [(0, 0, 0), (255, 255, 255)]  # 设置为1时  实现背景为黑目标为白
                        # seg_img = np.zeros((np.shape(pr)[0], np.shape(pr)[1], 3))
                        # for c in range(self.num_classes):
                        #     seg_img[:, :, 0] += ((pr[:, :] == c ) * self.colors[c][0]).astype('uint8')
                        #     seg_img[:, :, 1] += ((pr[:, :] == c ) * self.colors[c][1]).astype('uint8')
                        #     seg_img[:, :, 2] += ((pr[:, :] == c ) * self.colors[c][2]).astype('uint8')
                        seg_img = np.reshape(np.array(self.colorse, np.uint8)[np.reshape(pr, [-1])],
                                             [orininal_h, orininal_w, -1])

                        #max_w = max_circle(seg_img)
                        # ------------------------------------------------#
                        #   将新图片转换成Image的形式
                        # ------------------------------------------------#
                        # # 将图像转换为灰度
                        # gray = cv2.cvtColor(seg_img, cv2.COLOR_BGR2GRAY)
                        # # 使用二值化处理图像
                        # ret, binary_image = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
                        # # 查找二值化图像中的轮廓
                        # contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL,
                        #                                cv2.CHAIN_APPROX_SIMPLE)  # CHAIN_APPROX_SIMPLE
                        # # 遍历轮廓并绘制外接圆
                        # for contour in contours:
                        #     if len(contour) >= 5:
                        #         # 计算外接椭圆
                        #         ellipse = cv2.fitEllipse(contour)
                        #
                        #         # 绘制外接椭圆
                        #         cv2.ellipse(seg_img, ellipse, (0, 255, 0), 2)
                        r_image = Image.fromarray(np.uint8(seg_img))

                    elif self.mix_type == 2:
                        seg_img = (np.expand_dims(pr != 0, -1) * np.array(old_img, np.float32)).astype('uint8')
                        # ------------------------------------------------#
                        #   将新图片转换成Image的形式
                        # ------------------------------------------------#
                        r_image = Image.fromarray(np.uint8(seg_img))

                    dir_save_pathse = "img_seg/"
                    name1 = name[0 : -4]
                    name2 = name[-4 : ]
                    name3 = name1 + "_" +str(i) + name2
                    r_image.save(os.path.join(dir_save_pathse, name3.replace(".jpg", ".png")), quality=95,
                                 subsampling=0)
                    # ---------------------------------------------------------#
                    # 重计算分割位置中心点坐标、矩形长宽以及倾斜角度
                    # ---------------------------------------------------------#
                    gray = cv2.cvtColor(seg_img, cv2.COLOR_BGR2GRAY)
                    # 使用二值化处理图像
                    ret, binary_image = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
                    contours, hierarchy = cv2.findContours(binary_image, mode=cv2.RETR_LIST,
                                                           method=cv2.CHAIN_APPROX_SIMPLE)
                    if contours == ():
                        dot = tuple((0, 0))
                        hw = tuple((0, 0))
                        anc = 0
                    else:
                        dot, hw, anc = detect_rect(contours=contours)

                    compute = open('compute.txt', 'a', encoding='utf-8')

                    filename = name[:-4]
                    compute.write(str(filename))
                    compute.write("\n")
                    compute.write("中心点坐标：" + "x=" + "%.2f" % float(dot[0]) + "   " + "y=" + "%.2f" % float(dot[1]))
                    compute.write("\n")
                    compute.write(
                        "目标宽高：" + "h=" + "%.2f" % max(float(hw[0]), float(hw[1])) + "   " + "w=" + "%.2f" % min(
                            float(hw[0]), float(hw[1])))
                    compute.write("\n")
                    compute.close()

                    if i == 0:
                        all_hw = np.array([[int(hw[0]), int(hw[1])]])
                    else:
                        all_hw = np.append(all_hw, [[int(hw[0]), int(hw[1])]], axis=0)

                # ---------------------------------------------------------#
                # 切分割图片恢复回检测位置
                # ---------------------------------------------------------#
                # for i, c in list(enumerate(top_boxes)):
                top, left, bottom, right = top_boxes[i]
                top = max(0, np.floor(top).astype('int32'))
                left = max(0, np.floor(left).astype('int32'))
                bottom = min(image.size[1], np.floor(bottom).astype('int32'))
                right = min(image.size[0], np.floor(right).astype('int32'))

                image.paste(r_image, box=[left, top, right, bottom])

        #---------------------------------------------------------#
        #   设置字体与边框厚度
        #---------------------------------------------------------#
        font        = ImageFont.truetype(font='model_data/simhei.ttf', size=np.floor(3e-2 * image.size[1] + 0.5).astype('int32'))
        thickness   = int(max((image.size[0] + image.size[1]) // np.mean(self.input_shape), 1))
        #---------------------------------------------------------#
        #   计数
        #---------------------------------------------------------#
        if count:
            # ---------------------------------------------------#
            #   创建txt文件用于记数
            # ---------------------------------------------------#
            tpynum = open('tpynum.txt', 'r', encoding='utf-8')
            self.D = tpynum.readlines()
            tpynum.close()
            print("top_label:", top_label)
            classes_nums    = np.zeros([self.num_classes])
            for i in range(self.num_classes):
                num = np.sum(top_label == i)
                if num > 0:
                    print(self.class_names[i], " : ", num)
                    self.D[i] = int(self.D[i]) + num
                classes_nums[i] = num
            #print("classes_nums:", classes_nums)
        #tpynum.truncate(0)
            tpynum = open('tpynum.txt', 'w', encoding='utf-8')
            for i in range(0, self.num_classes):
                tpynum.writelines("%d" % + int(self.D[i]) + "\n")
            tpynum.close()


            self.num_classese = ["background", "fissure"]
            dotnum = open('dotnum.txt', 'a', encoding='utf-8')
            classes_nums        = np.zeros([2])
            total_points_num    = orininal_h * orininal_w
            # print('-' * 63)
            # print("|%25s | %15s | %15s|"%("Key", "Value", "Ratio"))
            # print('-' * 63)
            dotnum.write("\n")
            filename = name[:-4]
            dotnum.write(str(filename))
            for i in range(2):
                num     = np.sum(pr == i)
                ratio   = num / total_points_num * 100
                # if num > 0:
                #     print("|%25s | %15s | %14.2f%%|"%(str(self.num_classese[i]), str(num), ratio))
                #     print('-' * 63)
                classes_nums[i] = num
                dotnum.write("\n")
                dotnum.write(str(self.num_classese[i]) + "    " + str(num) + "    " +  str(ratio))

            # print("classes_nums:", classes_nums)
            dotnum.close()


        #---------------------------------------------------------#
        #   是否进行目标的裁剪
        #---------------------------------------------------------#
        if crop:
            for i, c in list((top_boxes)):
                top, left, bottom, right = top_boxes[i]
                top     = max(0, np.floor(top).astype('int32'))
                left    = max(0, np.floor(left).astype('int32'))
                bottom  = min(image.size[1], np.floor(bottom).astype('int32'))
                right   = min(image.size[0], np.floor(right).astype('int32'))

                filename = name[:-4]
                dir_save_path = "img_crop"
                if not os.path.exists(dir_save_path):
                    os.makedirs(dir_save_path)
                crop_image = image.crop([left, top, right, bottom])
                crop_image.save(os.path.join(dir_save_path, "crop_"+ filename + "_" + str(i) + ".jpg"), quality=95, subsampling=0)
                # print("save crop_" + filename + "_" + str(i) + ".jpg to " + dir_save_path)

        #---------------------------------------------------------#
        #   图像绘制
        #---------------------------------------------------------#
        for i, c in list(enumerate(top_label)):
            predicted_class = self.class_names[int(c)]
            box             = top_boxes[i]
            score           = top_conf[i]

            top, left, bottom, right = box

            top     = max(0, np.floor(top).astype('int32'))
            left    = max(0, np.floor(left).astype('int32'))
            bottom  = min(image.size[1], np.floor(bottom).astype('int32'))
            right   = min(image.size[0], np.floor(right).astype('int32'))

            #label = '{} {:.2f}'.format(predicted_class, score)
            # label = '{} {:.2f} {} {:.2f} {} {:.2f}'.format(predicted_class, score, "Area length", max(all_hw[i][0], all_hw[i][1]),
            #                                                "Area width", min(all_hw[i][0], all_hw[i][1]))
            label = '{} {:.2f}\n{} {:.2f}\n{} {:.2f}\n{} {:.2f}'.format("A_L", max(all_hw[i][0], all_hw[i][1]),
                                                            "A_W", min(all_hw[i][0], all_hw[i][1]), "C_W", max_w,
                                                                     "C_L", length)



            draw = ImageDraw.Draw(image)
            label_size = draw.textsize(label, font)

            label = label.encode('utf-8')
            #s = s.encode('utf-8')
            #输出检测框位置坐标
            #print(label, top, left, bottom, right)

            text_origins = np.array([right, top])
            if top - label_size[1] >= 0:
                text_origin = np.array([left, top - label_size[1]])
            else:
                text_origin = np.array([left, top + 1])

            for i in range(thickness):
                draw.rectangle([left + i, top + i, right - i, bottom - i], outline=self.colors[c])
            draw.rectangle([tuple(text_origin), tuple(text_origin + label_size)], fill=self.colors[c])
            draw.text(text_origin, str(label,'UTF-8'), fill=(0, 0, 0), font=font)
            #draw.text(text_origins, str(label, 'UTF-8'), fill=self.colors[c], font=font)
            del draw

        return image#, r_image

    def get_FPS(self, image, test_interval):
        image_shape = np.array(np.shape(image)[0:2])
        #---------------------------------------------------------#
        #   在这里将图像转换成RGB图像，防止灰度图在预测时报错。
        #   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
        #---------------------------------------------------------#
        image       = cvtColor(image)
        #---------------------------------------------------------#
        #   给图像增加灰条，实现不失真的resize
        #   也可以直接resize进行识别
        #---------------------------------------------------------#
        image_data  = resize_image(image, (self.input_shape[1], self.input_shape[0]), self.letterbox_image)
        #---------------------------------------------------------#
        #   添加上batch_size维度
        #---------------------------------------------------------#
        image_data  = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

        with torch.no_grad():
            images = torch.from_numpy(image_data)
            if self.cuda:
                images = images.cuda()
            #---------------------------------------------------------#
            #   将图像输入网络当中进行预测！
            #---------------------------------------------------------#
            outputs = self.net(images)
            outputs = self.bbox_util.decode_box(outputs)
            #---------------------------------------------------------#
            #   将预测框进行堆叠，然后进行非极大抑制
            #---------------------------------------------------------#
            results = self.bbox_util.non_max_suppression(outputs, self.num_classes, self.input_shape, 
                        image_shape, self.letterbox_image, conf_thres = self.confidence, nms_thres = self.nms_iou)
                                                    
        t1 = time.time()
        for _ in range(test_interval):
            with torch.no_grad():
                #---------------------------------------------------------#
                #   将图像输入网络当中进行预测！
                #---------------------------------------------------------#
                outputs = self.net(images)
                outputs = self.bbox_util.decode_box(outputs)
                #---------------------------------------------------------#
                #   将预测框进行堆叠，然后进行非极大抑制
                #---------------------------------------------------------#
                results = self.bbox_util.non_max_suppression(outputs, self.num_classes, self.input_shape, 
                            image_shape, self.letterbox_image, conf_thres = self.confidence, nms_thres = self.nms_iou)
                                
        t2 = time.time()
        tact_time = (t2 - t1) / test_interval
        return tact_time

    def detect_heatmap(self, image, heatmap_save_path):
        import cv2
        import matplotlib.pyplot as plt
        def sigmoid(x):
            y = 1.0 / (1.0 + np.exp(-x))
            return y
        #---------------------------------------------------------#
        #   在这里将图像转换成RGB图像，防止灰度图在预测时报错。
        #   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
        #---------------------------------------------------------#
        image       = cvtColor(image)
        #---------------------------------------------------------#
        #   给图像增加灰条，实现不失真的resize
        #   也可以直接resize进行识别
        #---------------------------------------------------------#
        image_data  = resize_image(image, (self.input_shape[1],self.input_shape[0]), self.letterbox_image)
        #---------------------------------------------------------#
        #   添加上batch_size维度
        #---------------------------------------------------------#
        image_data  = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

        with torch.no_grad():
            images = torch.from_numpy(image_data)
            if self.cuda:
                images = images.cuda()
            #---------------------------------------------------------#
            #   将图像输入网络当中进行预测！
            #---------------------------------------------------------#
            dbox, cls, x, anchors, strides = self.net(images)
            outputs = [xi.split((xi.size()[1] - self.num_classes, self.num_classes), 1)[1] for xi in x]
        
        plt.imshow(image, alpha=1)
        plt.axis('off')
        mask    = np.zeros((image.size[1], image.size[0]))
        for sub_output in outputs:
            sub_output = sub_output.cpu().numpy()
            b, c, h, w = np.shape(sub_output)
            sub_output = np.transpose(np.reshape(sub_output, [b, -1, h, w]), [0, 2, 3, 1])[0]
            score      = np.max(sigmoid(sub_output[..., :]), -1)
            score      = cv2.resize(score, (image.size[0], image.size[1]))
            normed_score    = (score * 255).astype('uint8')
            mask            = np.maximum(mask, normed_score)
            
        plt.imshow(mask, alpha=0.5, interpolation='nearest', cmap="jet")

        plt.axis('off')
        plt.subplots_adjust(top=1, bottom=0, right=1,  left=0, hspace=0, wspace=0)
        plt.margins(0, 0)
        plt.savefig(heatmap_save_path, dpi=200, bbox_inches='tight', pad_inches = -0.1)
        print("Save to the " + heatmap_save_path)
        plt.show()

    def convert_to_onnx(self, simplify, model_path):
        import onnx
        self.generate(onnx=True)

        im                  = torch.zeros(1, 3, *self.input_shape).to('cpu')  # image size(1, 3, 512, 512) BCHW
        input_layer_names   = ["images"]
        output_layer_names  = ["output"]
        
        # Export the model
        print(f'Starting export with onnx {onnx.__version__}.')
        torch.onnx.export(self.net,
                        im,
                        f               = model_path,
                        verbose         = False,
                        opset_version   = 12,
                        training        = torch.onnx.TrainingMode.EVAL,
                        do_constant_folding = True,
                        input_names     = input_layer_names,
                        output_names    = output_layer_names,
                        dynamic_axes    = None)

        # Checks
        model_onnx = onnx.load(model_path)  # load onnx model
        onnx.checker.check_model(model_onnx)  # check onnx model

        # Simplify onnx
        if simplify:
            import onnxsim
            print(f'Simplifying with onnx-simplifier {onnxsim.__version__}.')
            model_onnx, check = onnxsim.simplify(
                model_onnx,
                dynamic_input_shape=False,
                input_shapes=None)
            assert check, 'assert check failed'
            onnx.save(model_onnx, model_path)

        print('Onnx model save as {}'.format(model_path))

    def get_map_txt(self, image_id, image, class_names, map_out_path):
        f = open(os.path.join(map_out_path, "detection-results/"+image_id+".txt"), "w", encoding='utf-8') 
        image_shape = np.array(np.shape(image)[0:2])
        #---------------------------------------------------------#
        #   在这里将图像转换成RGB图像，防止灰度图在预测时报错。
        #   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
        #---------------------------------------------------------#
        image       = cvtColor(image)
        #---------------------------------------------------------#
        #   给图像增加灰条，实现不失真的resize
        #   也可以直接resize进行识别
        #---------------------------------------------------------#
        image_data  = resize_image(image, (self.input_shape[1], self.input_shape[0]), self.letterbox_image)
        #---------------------------------------------------------#
        #   添加上batch_size维度
        #---------------------------------------------------------#
        image_data  = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

        with torch.no_grad():
            images = torch.from_numpy(image_data)
            if self.cuda:
                images = images.cuda()
            #---------------------------------------------------------#
            #   将图像输入网络当中进行预测！
            #---------------------------------------------------------#
            outputs = self.net(images)
            outputs = self.bbox_util.decode_box(outputs)
            #---------------------------------------------------------#
            #   将预测框进行堆叠，然后进行非极大抑制
            #---------------------------------------------------------#
            results = self.bbox_util.non_max_suppression(outputs, self.num_classes, self.input_shape, 
                        image_shape, self.letterbox_image, conf_thres = self.confidence, nms_thres = self.nms_iou)
                                                    
            if results[0] is None: 
                return 

            top_label   = np.array(results[0][:, 5], dtype = 'int32')
            top_conf    = results[0][:, 4]
            top_boxes   = results[0][:, :4]

        for i, c in list(enumerate(top_label)):
            predicted_class = self.class_names[int(c)]
            box             = top_boxes[i]
            score           = str(top_conf[i])

            top, left, bottom, right = box
            if predicted_class not in class_names:
                continue

            f.write("%s %s %s %s %s %s\n" % (predicted_class, score[:6], str(int(left)), str(int(top)), str(int(right)),str(int(bottom))))

        f.close()
        return 
