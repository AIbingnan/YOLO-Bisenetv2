from .GhostNet import GhostBottleneck
from .Mobilenetv1 import conv_bn, conv_dw
from .Mobilenetv2 import InvertedResidual
from .Mobilenetv3 import InvertedResidualSE
from .ResNet import ResNetUnit
from.ShuffleNetV1 import ShuffleUnit
from .ShuffleNetv2 import ShuffleNetUnits
from .xception import Block
from .ESPnet import *
from .ESPnetv2 import *
from .Attention import *
from .VanillaNet import *

class ConvBNReLU(nn.Module):

    def __init__(self, in_chan, out_chan, ks=3, stride=1, padding=1,
                 dilation=1, groups=1, bias=False):
        super(ConvBNReLU, self).__init__()
        self.conv = nn.Conv2d(
                in_chan, out_chan, kernel_size=ks, stride=stride,
                padding=padding, dilation=dilation,
                groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_chan)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        feat = self.conv(x)
        feat = self.bn(feat)
        feat = self.relu(feat)
        return feat


class UpSample(nn.Module):

    def __init__(self, n_chan, factor=2):
        super(UpSample, self).__init__()
        out_chan = n_chan * factor * factor
        self.proj = nn.Conv2d(n_chan, out_chan, 1, 1, 0)
        self.up = nn.PixelShuffle(factor)
        self.init_weight()

    def forward(self, x):
        feat = self.proj(x)
        feat = self.up(feat)
        return feat

    def init_weight(self):
        nn.init.xavier_normal_(self.proj.weight, gain=1.)

class GhostNetDetail(nn.Module):

    def __init__(self):
        super(GhostNetDetail, self).__init__()

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ConvBNReLU(64, 64, 3, stride=1),
        )

        self.S2 = nn.Sequential(
            GhostBottleneck(64, 64, 64, 3, 2, False),
            GhostBottleneck(64, 128, 64, 3, 1, False),
            GhostBottleneck(64, 128, 64, 3, 1, True),
        )

        self.S3 = nn.Sequential(
            GhostBottleneck(64, 128, 128, 3, 2, False),
            GhostBottleneck(128, 256, 128, 3, 1, False),
            GhostBottleneck(128, 256, 128, 3, 1, True),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class MobileNetV1Detail(nn.Module):

    def __init__(self):
        super(MobileNetV1Detail, self).__init__()
        self.S1 = nn.Sequential(
            conv_bn(3, 64, 2),
            conv_dw(64, 64, 1),
        )
        self.S2 = nn.Sequential(
            conv_dw(64, 64, 2),
            conv_dw(64, 64, 1),
            conv_dw(64, 64, 1),
        )
        self.S3 = nn.Sequential(
            conv_dw(64, 128,  2),
            conv_dw(128, 128, 1),
            conv_dw(128, 128, 1),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class MobileNetV2Detail(nn.Module):

    def __init__(self):
        super(MobileNetV2Detail, self).__init__()
        self.S1 = nn.Sequential(
            InvertedResidual(3, 64, 1, 1),
            InvertedResidual(64, 64, 2, 1),
        )
        self.S2 = nn.Sequential(
            InvertedResidual(64, 64, 2, 1),
            InvertedResidual(64, 64, 1, 2),
            InvertedResidual(64, 64, 1, 2),
        )
        self.S3 = nn.Sequential(
            InvertedResidual(64, 128, 2, 1),
            InvertedResidual(128, 128, 1, 2),
            InvertedResidual(128, 128, 1, 2),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat


class MobileNetV3Detail(nn.Module):

    def __init__(self):
        super(MobileNetV3Detail, self).__init__()
        self.S1 = nn.Sequential(
            InvertedResidualSE(3, 3, 64, 3, 2, 0, 0),
            InvertedResidualSE(64, 64, 64, 3, 1, 1, 1),
        )
        self.S2 = nn.Sequential(
            InvertedResidualSE(64, 64, 64, 3, 2, 0, 0),
            InvertedResidualSE(64, 128, 64, 3, 1, 1, 1),
            InvertedResidualSE(64, 64, 64, 3, 1, 1, 1),
        )
        self.S3 = nn.Sequential(
            InvertedResidualSE(64, 64, 128, 3, 2, 0, 0),
            InvertedResidualSE(128, 256, 128, 3, 1, 1, 1),
            InvertedResidualSE(128, 128, 128, 3, 1, 1, 1),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class ResNetDetail(nn.Module):

    def __init__(self):
        super(ResNetDetail, self).__init__()
        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class ResNet1Detail(nn.Module): # conv 1×1 实现下采样和通道变换

    def __init__(self):
        super(ResNet1Detail, self).__init__()
        self.sample1 = nn.Conv2d(3, 64, kernel_size=1, stride=2)
        self.sample2 = nn.Conv2d(64, 64, kernel_size=1, stride=2)
        self.sample3 = nn.Conv2d(64, 128, kernel_size=1, stride=2)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        down1 = self.sample1(x)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(out1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2

        down3 = self.sample3(out2)
        feat3 = self.S3(out2)
        out3 = down3 + feat3

        return out3

class ResNetADetail(nn.Module):

    def __init__(self):
        super(ResNetADetail, self).__init__()
        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class ShuffleNetV1Detail(nn.Module):

    def __init__(self):
        super(ShuffleNetV1Detail, self).__init__()
        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ShuffleUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ShuffleUnit(64, 64),
            ShuffleUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ShuffleUnit(128, 128),
            ShuffleUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class ShuffleNetV2Detail(nn.Module):

    def __init__(self):
        super(ShuffleNetV2Detail, self).__init__()
        self.S1 = nn.Sequential(
            ShuffleNetUnits(3, 32, 2, 1),
            ShuffleNetUnits(32, 32 ,1, 4),
        )
        self.S2 = nn.Sequential(
            ShuffleNetUnits(32, 64, 2, 1),
            ShuffleNetUnits(64, 64 ,1, 4),
            ShuffleNetUnits(64, 64 ,1, 4),
        )
        self.S3 = nn.Sequential(
            ShuffleNetUnits(64, 128, 2, 1),
            ShuffleNetUnits(128, 128 ,1, 4),
            ShuffleNetUnits(128, 128 ,1, 4),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class ShuffleNetV2ADetail(nn.Module):

    def __init__(self):
        super(ShuffleNetV2ADetail, self).__init__()

        self.down1 = nn.Conv2d(3, 32, 1)
        self.down2 = nn.Conv2d(32, 64, 1)
        self.sample1 = InputProjectionA(1)
        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ShuffleNetUnits(3, 32, 2, 1),
            ShuffleNetUnits(32, 32 ,1, 4),
        )
        self.S2 = nn.Sequential(
            ShuffleNetUnits(32, 64, 2, 1),
            ShuffleNetUnits(64, 64 ,1, 4),
            ShuffleNetUnits(64, 64 ,1, 4),
        )
        self.S3 = nn.Sequential(
            ShuffleNetUnits(64, 128, 2, 1),
            ShuffleNetUnits(128, 128 ,1, 4),
            ShuffleNetUnits(128, 128 ,1, 4),
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        X2 = self.down2(down1)
        down2 = self.sample2(X2)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class XceptionDetail(nn.Module):

    def __init__(self):
        super(XceptionDetail, self).__init__()
        self.S1 = nn.Sequential(
            Block(3, 32, 2),
            #Block(32, 32 ,1),
        )
        self.S2 = nn.Sequential(
            Block(32, 64, 2),
            #Block(64, 64 ,1),
            #Block(64, 64 ,1),
        )
        self.S3 = nn.Sequential(
            Block(64, 128, 2),
            #Block(128, 128 ,1),
            #Block(128, 128 ,1),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.S2(feat)
        feat = self.S3(feat)
        return feat

class ESPDetail(nn.Module):

    def __init__(self):
        super(ESPDetail, self).__init__()

        self.sample1 = InputProjectionA(1)
        self.sample2 = InputProjectionA(2)
        self.sample3 = InputProjectionA(3)

        self.CBR = CBR(3, 32, 3, 2)
        self.Dilate_1 = DilatedParllelResidualBlockB(64, 64)
        self.level1_0 = DownSamplerB(32 + 3, 64)
        self.Dilate_2 = DilatedParllelResidualBlockB(128, 128)
        self.level2_0 = DownSamplerB(64 + 3, 128)

    def forward(self, x):

        feat1 = self.Dilate_1(self.level1_0 (torch.cat([self.CBR(x), self.sample1(x)], 1)))
        feat = self.Dilate_2(self.level2_0(torch.cat([feat1, self.sample2(x)], 1)))


        return feat

class ESPv2Detail(nn.Module):

    def __init__(self):
        super(ESPv2Detail, self).__init__()


        self.CBR = CBR(3, 32, 3, 2)
        self.level1_0 = EESP(32, 32)

        self.Dilate_2 = DownSampler(32, 64)
        self.level2_0 = EESP(64, 64)
        self.Dilate_3 = DownSampler(64, 128)
        self.level3_0 = EESP(128, 128)


    def forward(self, x):

        feat = self.CBR(x)
        feat = self.level1_0(feat)
        feat = self.Dilate_2(feat)
        feat = self.level2_0(feat)
        feat = self.Dilate_3(feat)
        feat = self.level3_0(feat)

        return feat



"""----------------------------------添加注意力机制的ResNet轻量化网络-----------------------------------"""

class ResNetSEDetail(nn.Module):

    def __init__(self):
        super(ResNetSEDetail, self).__init__()

        self.se1 = SE(64, 64)
        self.se2 = SE(64, 64)
        self.se3 = SE(128, 128)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.se1(feat)
        feat = self.S2(feat)
        feat = self.se2(feat)
        feat = self.S3(feat)
        feat = self.se3(feat)
        return feat



class ResNetCBAMDetail(nn.Module):

    def __init__(self):
        super(ResNetCBAMDetail, self).__init__()

        self.se1 = CBAM(64, 64)
        self.se2 = CBAM(64, 64)
        self.se3 = CBAM(128, 128)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.se1(feat)
        feat = self.S2(feat)
        feat = self.se2(feat)
        feat = self.S3(feat)
        feat = self.se3(feat)
        return feat


class ResNetECADetail(nn.Module):

    def __init__(self):
        super(ResNetECADetail, self).__init__()

        self.se1 = ECA(64, 64)
        self.se2 = ECA(64, 64)
        self.se3 = ECA(128, 128)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.se1(feat)
        feat = self.S2(feat)
        feat = self.se2(feat)
        feat = self.S3(feat)
        feat = self.se3(feat)
        return feat


class ResNetCADetail(nn.Module):

    def __init__(self):
        super(ResNetCADetail, self).__init__()

        self.se1 = CoordAtt(64, 64)
        self.se2 = CoordAtt(64, 64)
        self.se3 = CoordAtt(128, 128)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        feat = self.S1(x)
        feat = self.se1(feat)
        feat = self.S2(feat)
        feat = self.se2(feat)
        feat = self.S3(feat)
        feat = self.se3(feat)
        return feat



class ResNetADetail(nn.Module):

    def __init__(self):
        super(ResNetADetail, self).__init__()
        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3



class ResNetADetailSE(nn.Module):

    def __init__(self):
        super(ResNetADetailSE, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            SE(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            SE(64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            SE(128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class ResNetADetailCBAM(nn.Module):

    def __init__(self):
        super(ResNetADetailCBAM, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            CBAM(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            CBAM(64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            CBAM(128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class ResNetADetailECA(nn.Module):

    def __init__(self):
        super(ResNetADetailECA, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ECA(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            ECA(64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            ECA(128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class ResNetADetailCA(nn.Module):

    def __init__(self):
        super(ResNetADetailCA, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            CoordAtt(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            CoordAtt(64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            CoordAtt(128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3


class ResNetADetailA2(nn.Module):

    def __init__(self):
        super(ResNetADetailA2, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            A2(64, 64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            A2(64, 64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            A2(128, 128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3



class ResNetADetailEMAU(nn.Module):

    def __init__(self):
        super(ResNetADetailEMAU, self).__init__()

        self.down1 = nn.Conv2d(3, 64, 1)
        self.sample1 = InputProjectionA(1)

        self.sample2 = InputProjectionA(1)

        self.S1 = nn.Sequential(
            ConvBNReLU(3, 64, 3, stride=2),
            ResNetUnit(64, 64),
            EMAU(64, 64),
        )
        self.S2 = nn.Sequential(
            ConvBNReLU(64, 64, 3, stride=2),
            ResNetUnit(64, 64),
            ResNetUnit(64, 64),
            EMAU(64, 64)
        )
        self.S3 = nn.Sequential(
            ConvBNReLU(64, 128, 3, stride=2),
            ResNetUnit(128, 128),
            ResNetUnit(128, 128),
            EMAU(128, 128)
        )

    def forward(self, x):
        x1 = self.down1(x)
        down1 = self.sample1(x1)
        feat1 = self.S1(x)
        out1 = down1 + feat1

        down2 = self.sample2(down1)
        feat2 = self.S2(out1)
        out2 = down2 + feat2


        feat3 = self.S3(out2)

        return feat3